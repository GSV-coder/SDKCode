Copy the downloaded INVIDI video advertising android SDK library file to this folder.
