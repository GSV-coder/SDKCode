
var content = document.getElementById('video_player');
var videoContainer = document.getElementById('video_container');
var adContainer = document.getElementById('adContainer');

var session = null;
var adPlayer = null;

OO.Pulse.setPulseHost('https://pulse-demo.videoplaza.tv');
OO.Pulse.debug = true

var contentMetadata = {
  tags: [ 'standard-linears' ],
  category: 'skip-always'
};

var requestSettings = {
  linearPlaybackPositions: [ 10 ], // Request 2 mid-roll breaks
  nonlinearPlaybackPositions: [ 5, 25 ] // .. and 2 overlays
};

session = OO.Pulse.createSession(contentMetadata, requestSettings);
adPlayer = OO.Pulse.createAdPlayer({ adContainerElement: adContainer });


var adPlayerListener = {
  startContentPlayback: function() {
    content.play();
    videoContainer.style.display = 'block'; // or any other means to make the content player visible
  },

  pauseContentPlayback: function() {
    content.pause();
    videoContainer.style.display = 'none'; // or any other means to make the content player invisible
  },

  illegalOperationOccurred: function(message) {
    console.warn('Illegal operation: ', message);
  },

  sessionEnded: function() {
    videoContainer.style.display = 'block';
  },

  openClickThrough: function(url) {
    window.open(url);

    adPlayer.adClickThroughOpened();
  }
};

content.addEventListener('play', onPlay);
content.addEventListener('pause', onPause);
content.addEventListener('timeupdate', onTimeUpdate);
content.addEventListener('ended', onEnded);

var initialPlay = true;

function onPlay() {
  if(initialPlay) {
    initialPlay = false;
    content.pause(); // Pause the content so we can play pre-rolls
    adPlayer.startSession(session, adPlayerListener); // Start the Ad Player event flow
  } else {
    adPlayer.contentStarted();
  }
}

function onTimeUpdate() {
  adPlayer.contentPositionChanged(content.currentTime);
}

function onPause() {
  // Let the Ad Player know the content is paused
  adPlayer.contentPaused();
}

function onEnded() {
  adPlayer.contentFinished();
}



adPlayer.addEventListener(OO.Pulse.AdPlayer.Events.AD_CLICKED, function(event, data) {
  window.open(data.url);
  adPlayer.adClickThroughOpened();
});


//adPlayer.getOverlayDiv().style.width = '60%';

//session = OO.Pulse.createSession(contentMetadata, { seekMode: OO.Pulse.SeekMode.PLAY_LAST });
